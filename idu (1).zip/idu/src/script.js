document.addEventListener("DOMContentLoaded", () => {

  // -------------------------
  // PAGE NAVIGATION
  // -------------------------
  const pages = document.querySelectorAll(".page");

  function showPage(id) {
    pages.forEach(p => p.classList.remove("active"));
    document.getElementById(id).classList.add("active");
    window.scrollTo(0, 0);
  }

  document.querySelectorAll("[data-page]").forEach(btn => {
    btn.addEventListener("click", () => {
      showPage(btn.dataset.page);
    });
  });

  // -------------------------
  // SLIDESHOW
  // -------------------------
  const slides = document.querySelectorAll(".slide");
  let i = 0;

  if (slides.length > 0) {
    setInterval(() => {
      slides[i].classList.remove("active");
      i = (i + 1) % slides.length;
      slides[i].classList.add("active");
    }, 4000);
  }

  // -------------------------
  // CODEPEN IMAGE FIX
  // -------------------------
  if (window.location.href.includes("codepen")) {

    // Hide all images
    document.querySelectorAll("img").forEach(img => {
      img.style.display = "none";
    });

    // Add placeholder text so layout isn't empty
    document.querySelectorAll(".event").forEach(event => {
      const note = document.createElement("p");
      note.textContent = "[Image shown in final version]";
      note.style.opacity = "0.5";
      note.style.fontStyle = "italic";
      event.appendChild(note);
    });

  }

});